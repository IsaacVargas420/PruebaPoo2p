/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Propietario;
import modelo.Vehiculo;

import Controlador.ControladorPropietario;
import Controlador.ControladorVehiculo;

public class Main {
    public static void main(String[] args) {
        // Inicialización de listas de propietarios y vehículos
        List<Propietario> propietarios = new ArrayList<>();
        List<Vehiculo> vehiculos = new ArrayList<>();

        // Creación de instancias de las vistas
        MainP vistaPropietario = new MainP(propietarios);
        MainV vistaVehiculo = new MainV(vehiculos, propietarios);

        // Configuración de la conexión a la base de datos
        String url = "jdbc:mysql://localhost:3306/tu_base_de_datos";
        String user = "tu_usuario";
        String password = "tu_contraseña";
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(url, user, password);

            // Creación de instancias de los controladores
            ControladorVehiculo controladorVehiculo = new ControladorVehiculo(vistaVehiculo, connection);
            ControladorPropietario controladorPropietario = new ControladorPropietario(vistaPropietario, controladorVehiculo, connection);

            try (Scanner scanner = new Scanner(System.in)) {
                boolean running = true;

                while (running) {
                    System.out.println("Menú Principal:");
                    System.out.println("1. Crear Propietario");
                    System.out.println("2. Leer Propietario");
                    System.out.println("3. Actualizar Propietario");
                    System.out.println("4. Eliminar Propietario");
                    System.out.println("5. Añadir Vehículo a Propietario");
                    System.out.println("6. Mostrar todos los Propietarios");
                    System.out.println("7. Crear Vehículo");
                    System.out.println("8. Leer Vehículo");
                    System.out.println("9. Actualizar Vehículo");
                    System.out.println("10. Eliminar Vehículo");
                    System.out.println("11. Mostrar todos los Vehículos");
                    System.out.println("12. Salir");
                    System.out.print("Seleccione una opción: ");
                    int option = scanner.nextInt();
                    scanner.nextLine(); // Limpiar buffer

                    switch (option) {
                        case 1:
                            controladorPropietario.createPropietario();
                            break;
                        case 2:
                            controladorPropietario.readPropietario();
                            break;
                        case 3:
                            controladorPropietario.updatePropietario();
                            break;
                        case 4:
                            controladorPropietario.deletePropietario();
                            break;
                        case 5:
                            controladorPropietario.agregarVehiculoPropietario();
                            break;
                        case 6:
                            controladorPropietario.displayAllPropietarios();
                            break;
                        case 7:
                            // Aquí se debe pedir el id del propietario al que se le va a asociar el vehículo
                            System.out.print("Ingrese el ID del propietario al que se asociará el vehículo: ");
                            int propietarioId = scanner.nextInt();
                            scanner.nextLine(); // Limpiar buffer
                            controladorVehiculo.createVehiculo(propietarioId);
                            break;
                        case 8:
                            controladorVehiculo.readVehiculo();
                            break;
                        case 9:
                            controladorVehiculo.updateVehiculo();
                            break;
                        case 10:
                            controladorVehiculo.deleteVehiculo();
                            break;
                        case 11:
                            controladorVehiculo.displayAllVehiculos();
                            break;
                        case 12:
                            running = false;
                            break;
                        default:
                            System.out.println("Opción no válida. Por favor, intente de nuevo.");
                            break;
                    }
                }
            } finally {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

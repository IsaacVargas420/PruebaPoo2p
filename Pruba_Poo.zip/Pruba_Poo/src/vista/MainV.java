/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author Asus
 */
import java.util.List;
import java.util.Scanner;
import modelo.Propietario;
import modelo.Vehiculo;

public class MainV {
    private final Scanner scanner;
    private final List<Vehiculo> vehiculos;
    private final List<Propietario> propietarios;

    public MainV(List<Vehiculo> vehiculos, List<Propietario> propietarios) {
        this.scanner = new Scanner(System.in);
        this.vehiculos = vehiculos;
        this.propietarios = propietarios;
    }

    public Vehiculo createVehiculo(int propietarioId) {
        System.out.println("Ingrese la marca del vehículo:");
        String marca = scanner.nextLine();
        System.out.println("Ingrese el modelo del vehículo:");
        String modelo = scanner.nextLine();
        System.out.println("Ingrese el año del vehículo:");
        int año = scanner.nextInt();
        // Crear y devolver un nuevo objeto Vehiculo sin ID. Asignar ID en la base de datos o en otro lugar.
        return new Vehiculo(0, marca, modelo, año, propietarioId);
    }

    public int getIdVehiculo() {
        System.out.println("Ingrese el ID del vehículo:");
        return scanner.nextInt();
    }

    public void displayVehiculo(Vehiculo vehiculo) {
        if (vehiculo != null) {
            System.out.println("ID: " + vehiculo.getId());
            System.out.println("Marca: " + vehiculo.getMarca());
            System.out.println("Modelo: " + vehiculo.getModelo());
            System.out.println("Año: " + vehiculo.getAño());
            System.out.println("ID del Propietario: " + vehiculo.getPropietarioId());
        } else {
            System.out.println("Vehículo no encontrado.");
        }
    }

    public Vehiculo getVehiculoDetails() {
        System.out.println("Ingrese el ID del vehículo:");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        // Obtener detalles del vehículo por ID desde una lista o base de datos
        return getVehiculoDetails(id);
    }

    // Método para obtener detalles del vehículo por ID
    private Vehiculo getVehiculoDetails(int id) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getId() == id) {
                return vehiculo;
            }
        }
        return null; // Retorna null si no se encuentra
    }

    public int getVehiculoId() {
        return getIdVehiculo(); // Método simplificado para obtener ID
    }

    public void displayAllVehiculos(List<Vehiculo> vehiculos1) {
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println(vehiculo.toString());
        }
    }

    // Método para obtener los detalles de un propietario dado su ID
    public Propietario getPropietarioDetails(int propietarioId) {
        for (Propietario propietario : propietarios) {
            if (propietario.getId() == propietarioId) {
                return propietario;
            }
        }
        return null; // Retorna null si no se encuentra
    }

    public void displayAllPropietarios() {
        for (Propietario propietario : propietarios) {
            System.out.println(propietario.toString());
        }
    }
}

 
    
   


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Propietario;

public class MainP {
    private final Scanner scanner;
    private final List<Propietario> propietarios;

    // Constructor que acepta una lista de propietarios
    public MainP(List<Propietario> propietarios) {
        this.scanner = new Scanner(System.in);
        this.propietarios = propietarios;
    }

    // Constructor por defecto
    public MainP() {
        this.scanner = new Scanner(System.in);
        this.propietarios = new ArrayList<>(); // Inicializa la lista vacía si no se proporciona una lista
    }

    public Propietario createPropietario() {
        System.out.println("Ingrese el ID del propietario:");
        int id = scanner.nextInt();
        scanner.nextLine(); // Clear the buffer
        System.out.println("Ingrese el nombre del propietario:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese la dirección del propietario:");
        String direccion = scanner.nextLine();
        System.out.println("Ingrese el teléfono del propietario:");
        String telefono = scanner.nextLine();
        return new Propietario(id, nombre, direccion, telefono);
    }

    public int getPropietarioId() {
        System.out.println("Ingrese el ID del propietario:");
        return scanner.nextInt();
    }

    public void displayPropietario(Propietario propietario) {
        if (propietario != null) {
            System.out.println("ID: " + propietario.getId());
            System.out.println("Nombre: " + propietario.getNombre());
            System.out.println("Dirección: " + propietario.getDireccion());
            System.out.println("Teléfono: " + propietario.getTelefono());
            System.out.println("Vehículos: " + propietario.getVehiculos().size());
        } else {
            System.out.println("Propietario no encontrado.");
        }
    }

    public Propietario getPropietarioDetails(int propietarioId) {
        for (Propietario propietario : propietarios) {
            if (propietario.getId() == propietarioId) {
                return propietario;
            }
        }
        return null; // o lanzar una excepción si no se encuentra
    }

    public int getPropietarioId(Propietario propietario) {
        return propietario.getId();
    }

    public void displayAllPropietarios() {
        for (Propietario propietario : propietarios) {
            System.out.println(propietario.toString());
        }
    }

    public void displayAllPropietarios(List<Propietario> propietarios) {
        for (Propietario propietario : propietarios) {
            System.out.println(propietario.toString());
        }
    }
}







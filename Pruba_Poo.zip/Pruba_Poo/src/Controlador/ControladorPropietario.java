/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author Asus
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Propietario;
import vista.MainP;

public class ControladorPropietario {
    private final MainP vistaPropietario;
    private final ControladorVehiculo controladorVehiculo;
    private final Connection connection;

    public ControladorPropietario(MainP vistaPropietario, ControladorVehiculo controladorVehiculo, Connection connection) {
        this.vistaPropietario = vistaPropietario;
        this.controladorVehiculo = controladorVehiculo;
        this.connection = connection;
    }

    public void createPropietario() {
        Propietario P1 = vistaPropietario.getPropietarioDetails(1);
        String query = "INSERT INTO Propietarios (nombre, direccion, telefono) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, P1.getNombre());
            statement.setString(2, P1.getDireccion());
            statement.setString(3, P1.getTelefono());
            statement.executeUpdate();
            System.out.println("Propietario creado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void readPropietario() {
        int id = vistaPropietario.getPropietarioId();
        String query = "SELECT * FROM Propietarios WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Propietario propietario = new Propietario(
                        resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getString("direccion"),
                        resultSet.getString("telefono")
                );
                vistaPropietario.displayPropietario(propietario);
            } else {
                System.out.println("Propietario no encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePropietario() {
        Propietario P2 = vistaPropietario.getPropietarioDetails(1);
        String query = "UPDATE Propietarios SET nombre = ?, direccion = ?, telefono = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, P2.getNombre());
            statement.setString(2, P2.getDireccion());
            statement.setString(3, P2.getTelefono());
            statement.setInt(4, P2.getId());
            statement.executeUpdate();
            System.out.println("Propietario actualizado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePropietario() {
        int id = vistaPropietario.getPropietarioId();
        String query = "DELETE FROM Propietarios WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.executeUpdate();
            System.out.println("Propietario eliminado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displayAllPropietarios() {
        String query = "SELECT * FROM Propietarios";
        try (PreparedStatement statement = connection.prepareStatement(query); ResultSet resultSet = statement.executeQuery()) {
            List<Propietario> propietarios = new ArrayList<>();
            while (resultSet.next()) {
                Propietario propietario = new Propietario(
                        resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getString("direccion"),
                        resultSet.getString("telefono")
                );
                propietarios.add(propietario);
            }
            vistaPropietario.displayAllPropietarios(propietarios);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agregarVehiculoPropietario() {
        int propietarioId = vistaPropietario.getPropietarioId();
        controladorVehiculo.createVehiculo(propietarioId);
    }
}

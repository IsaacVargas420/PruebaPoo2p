/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author Asus
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Vehiculo;
import vista.MainV;

public class ControladorVehiculo {
    private final MainV vistaVehiculo;
    private final Connection connection;

    // Constructor que acepta la vista y la conexión
    public ControladorVehiculo(MainV vistaVehiculo, Connection connection) {
        this.vistaVehiculo = vistaVehiculo;
        this.connection = connection;
    }

    public void createVehiculo(int propietarioId) {
        Vehiculo vehiculo = vistaVehiculo.createVehiculo(propietarioId);
        String query = "INSERT INTO Vehiculos (marca, modelo, año, propietarioId) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, vehiculo.getMarca());
            statement.setString(2, vehiculo.getModelo());
            statement.setInt(3, vehiculo.getAño());
            statement.setInt(4, vehiculo.getPropietarioId());
            statement.executeUpdate();
            System.out.println("Vehículo creado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void readVehiculo() {
        int id = vistaVehiculo.getVehiculoId();
        String query = "SELECT * FROM Vehiculos WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Vehiculo vehiculo = new Vehiculo(
                    resultSet.getInt("id"),
                    resultSet.getString("marca"),
                    resultSet.getString("modelo"),
                    resultSet.getInt("año"),
                    resultSet.getInt("propietarioId")
                );
                vistaVehiculo.displayVehiculo(vehiculo);
            } else {
                System.out.println("Vehículo no encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateVehiculo() {
        Vehiculo vehiculo = vistaVehiculo.getVehiculoDetails();
        String query = "UPDATE Vehiculos SET marca = ?, modelo = ?, año = ?, propietarioId = ? WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, vehiculo.getMarca());
            statement.setString(2, vehiculo.getModelo());
            statement.setInt(3, vehiculo.getAño());
            statement.setInt(4, vehiculo.getPropietarioId());
            statement.setInt(5, vehiculo.getId());
            statement.executeUpdate();
            System.out.println("Vehículo actualizado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteVehiculo() {
        int id = vistaVehiculo.getVehiculoId();
        String query = "DELETE FROM Vehiculos WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.executeUpdate();
            System.out.println("Vehículo eliminado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displayAllVehiculos() {
        String query = "SELECT * FROM Vehiculos";

        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            List<Vehiculo> vehiculos = new ArrayList<>();
            while (resultSet.next()) {
                Vehiculo vehiculo = new Vehiculo(
                    resultSet.getInt("id"),
                    resultSet.getString("marca"),
                    resultSet.getString("modelo"),
                    resultSet.getInt("año"),
                    resultSet.getInt("propietarioId")
                );
                vehiculos.add(vehiculo);
            }
            vistaVehiculo.displayAllVehiculos(vehiculos);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
